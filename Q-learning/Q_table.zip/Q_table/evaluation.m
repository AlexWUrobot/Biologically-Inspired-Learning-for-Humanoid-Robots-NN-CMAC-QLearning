function [ ] = evaluation( )

P0 = textread('/Users/apple/Desktop/Q_0_0.txt');
P1 = textread('/Users/apple/Desktop/Q_0_1.txt');
P2 = textread('/Users/apple/Desktop/Q_0_2.txt');
P3 = textread('/Users/apple/Desktop/Q_0_3.txt');
P4 = textread('/Users/apple/Desktop/Q_0_4.txt');
P5 = textread('/Users/apple/Desktop/Q_0_5.txt');
P6 = textread('/Users/apple/Desktop/Q_0_6.txt');
P7 = textread('/Users/apple/Desktop/Q_0_7.txt');
P8 = textread('/Users/apple/Desktop/Q_0_8.txt');
P9 = textread('/Users/apple/Desktop/Q_0_9.txt');
P10 = textread('/Users/apple/Desktop/Q_0_10.txt');
P11 = textread('/Users/apple/Desktop/Q_0_11.txt');
P12 = textread('/Users/apple/Desktop/Q_0_12.txt');
P13 = textread('/Users/apple/Desktop/Q_0_13.txt');
P14 = textread('/Users/apple/Desktop/Q_0_14.txt');
P15 = textread('/Users/apple/Desktop/Q_0_15.txt');
P16 = textread('/Users/apple/Desktop/Q_0_16.txt');
P17 = textread('/Users/apple/Desktop/Q_0_17.txt');
P18 = textread('/Users/apple/Desktop/Q_0_18.txt');
P19 = textread('/Users/apple/Desktop/Q_0_19.txt');
P20 = textread('/Users/apple/Desktop/Q_0_20.txt');
P21 = textread('/Users/apple/Desktop/Q_0_21.txt');
P22 = textread('/Users/apple/Desktop/Q_0_22.txt');
P23 = textread('/Users/apple/Desktop/Q_0_23.txt');
P24 = textread('/Users/apple/Desktop/Q_0_24.txt');
P25 = textread('/Users/apple/Desktop/Q_0_25.txt');
P26 = textread('/Users/apple/Desktop/Q_0_26.txt');
P27 = textread('/Users/apple/Desktop/Q_0_27.txt');
P28 = textread('/Users/apple/Desktop/Q_0_28.txt');
% P29 = textread('/Users/apple/Desktop/Q_0_29.txt');
% P30 = textread('/Users/apple/Desktop/Q_0_30.txt');
% P31 = textread('/Users/apple/Desktop/Q_0_31.txt');
% P32 = textread('/Users/apple/Desktop/Q_0_32.txt');
% P33 = textread('/Users/apple/Desktop/Q_0_33.txt');
% P34 = textread('/Users/apple/Desktop/Q_0_34.txt');


for i = 1:15
    
%     PP(i,j)= P0();

    PP(i,1)=P0(1,i);
    PP(i,2)=P1(1,i);
    PP(i,3)=P2(1,i);
    PP(i,4)=P3(1,i);
    PP(i,5)=P4(1,i);
    PP(i,6)=P5(1,i);
    PP(i,7)=P6(1,i);
    PP(i,8)=P7(1,i);
    PP(i,9)=P8(1,i);
    PP(i,10)=P9(1,i);
    PP(i,11)=P10(1,i);
    PP(i,12)=P11(1,i);
    PP(i,13)=P12(1,i);
    PP(i,14)=P13(1,i);
    PP(i,15)=P14(1,i);
    PP(i,16)=P15(1,i);
    PP(i,17)=P16(1,i);
    PP(i,18)=P17(1,i);
    PP(i,19)=P18(1,i);
    PP(i,20)=P19(1,i);
    PP(i,21)=P20(1,i);
    PP(i,22)=P21(1,i);
    PP(i,23)=P22(1,i);
    PP(i,24)=P23(1,i);
    PP(i,25)=P24(1,i);
    PP(i,26)=P25(1,i);
    PP(i,27)=P26(1,i);
    PP(i,28)=P27(1,i);
    PP(i,29)=P28(1,i);
%     PP(i,30)=P29(1,i);
%     PP(i,31)=P30(1,i);
%     PP(i,32)=P31(1,i);
%     PP(i,33)=P32(1,i);


end

disp(PP)
figure
title('Goalkeeper Position: 0')
for j=1:5
    
    for i=1:28 %18
        
            
            subplot(5,1,j)
            
            
            line([i,i+1],[PP((j-1)*3+1,i),PP((j-1)*3+1,i+1)],'color','r');  
            hold on;
            line([i,i+1],[PP((j-1)*3+2,i),PP((j-1)*3+2,i+1)],'color','g');  
            hold on;
            line([i,i+1],[PP((j-1)*3+3,i),PP((j-1)*3+3,i+1)],'color','b');  
            hold on;

    
    grid on
    xlabel('Times')
    ylabel('Reward')
    
    legend('move in','move out','kicking')

    hold on
    end
end



